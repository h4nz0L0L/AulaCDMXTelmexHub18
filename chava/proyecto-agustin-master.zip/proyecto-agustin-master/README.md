# proyecto-agustin
Proyecto final 

# Motivación o problemática

 ## Culturizar
1.-Concientizar la población con respecto a la lectura, la difusión cultural 
para informar al público en general de la importancia de leer, tener centros de acopio para 
donación de libros y lugares donde adquirirlos.


# Objetivo


1.- Provocar un impacto social y cultural al tener al alcance un libro, ayudar a tener mayor distribución del mismo, 
realizando comunidades en las cuales se junten librerias y editoriales para apoyar a que lleguen libros a 
comunidades rurales. Además de ayudar a las personas que se dedican a vender libros, pequeñas librerias para que 
puedan lograr mayores ingresos y su trabajo crezca.


# Solución


1.- Realizar una página la cual exista un mapeo de las zonas en donde las personas venden o distribuyen libros para que vendan más, 
encuentren también los lugares que se pueden ir aportar o donar libros, complementando con los diferentes lugares o puntos de la ciudad 
y/o estados donde se realizan FERIAS DEL LIBROS/ BAZARES7 ETC.



# Recomendación 

Priorizar ubicar librerias y negocios dedicados a la venta de libros. 
Buscar lugares que se dediquen a la recolección de libros y que se dedique ayudar a comunidades 
para que tengan los materiales para poder impulsar el conocimiento dentro de ellas.